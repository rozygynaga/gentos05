<?php
include "log.php";
header('location:video.swf');
?>
