<?php
include "log.php";
header('location:index.html');
?>
